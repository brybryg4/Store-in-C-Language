﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.Odbc; // Database Libraries
using System.Diagnostics; // Debugging Libraries

namespace _2175_MGIS_350_01_Final
{
    class CarDatabaseClass
    {
        // Database Objects
        OdbcConnection dbConn;
        OdbcCommand dbCmd;
        OdbcDataReader dbReader;

        public CarDatabaseClass()
        {
            dbConn = new OdbcConnection("Driver={SQL Server};"
                + "Server=scb-sv-mgis-4.main.ad.rit.edu\\mgismssql;"
                + "DataBase=MGIS350_2175_8;"
                + "Uid=bxg3690;"
                + "Pwd=dtoymltc#&5231XOWP");
        }

        private void ExecuteQuery(string Query)
        {
            try
            {
                Debug.WriteLine("");
                Debug.WriteLine("SQL Query: " + Query);
                Debug.WriteLine("");

                // Building command to database and executing the query string 
                dbCmd = new OdbcCommand(Query, dbConn);

                // Opening the connection
                dbConn.Open();

                // Executing the query and closing the connection
                dbReader = dbCmd.ExecuteReader();
            }
            catch (Exception ex)
            {
                // Determine if database is open.  If so close it.
                if (dbConn.State.ToString() == "Open")
                {
                    this.CloseDatabase();
                }
                // Display Error
                System.Windows.Forms.MessageBox.Show("Error:\n\n" + ex.ToString() + "\n");
            }
        }

        private void CloseDatabase()
        {
            // Determine if database is open.  If so close it.
            if (dbConn.State.ToString() == "Open")
            {
                // Closing connection
                dbConn.Close();
            }
        }


        public void DisplayTransactions(System.Windows.Forms.ListBox output, string carmodel)
        {
            output.Items.Clear();

            this.ExecuteQuery("SELECT customerName, purchasePrice FROM finalExam WHERE carMakeModel = '" + carmodel + "';");

            while(dbReader.Read())
            {
                output.Items.Add(dbReader["customerName"] + " - " + dbReader["purchasePrice"].ToString());
            }

            this.CloseDatabase();
        }

        public void AddTransaction(string customername, string carmodel, double price)
        {
            this.ExecuteQuery("INSERT INTO finalexam (customerName, carMakeModel, purchasePrice) VALUES ('" + customername + "', '" + carmodel + "', " + price + ");");

            this.CloseDatabase();
        }

        public double GetBalance(string carmodel)
        {
            double balance = 0;

            this.ExecuteQuery("SELECT AVG(purchasePrice) AS Balance FROM finalexam WHERE carMakeModel = '" + carmodel + "';");

            while(dbReader.Read())
            {
                if (dbReader.IsDBNull(0) == false)
                {
                    balance = Convert.ToDouble(dbReader["Balance"]);
                }
            }

            this.CloseDatabase();
            return balance;
        }
    }

}
