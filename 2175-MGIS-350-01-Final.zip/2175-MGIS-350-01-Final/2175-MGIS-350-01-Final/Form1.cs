﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _2175_MGIS_350_01_Final
{
    public partial class Form1 : Form
    {
        CarDatabaseClass myDB = new CarDatabaseClass();

        public Form1()
        {
            InitializeComponent();

            // Setting up combobox
            cboCarMakeModel.DropDownStyle = ComboBoxStyle.DropDownList;
            cboCarMakeModel.Items.Add("Chevy Cruz");
            cboCarMakeModel.Items.Add("Ford Focus");
            cboCarMakeModel.SelectedIndex = 0;
        }

        private void btnSubmit_Click(object sender, EventArgs e)
        {
            double price = 0;

            if(double.TryParse(txtPurchasePrice.Text, out price))
            {
                myDB.AddTransaction(txtCustomerName.Text, cboCarMakeModel.Text, price);
                myDB.DisplayTransactions(lstPurchases, cboCarMakeModel.Text);
                lblAveragePrice.Text = myDB.GetBalance(cboCarMakeModel.Text).ToString("c");
            }
            else
            {
               MessageBox.Show("Please enter a valid number");
            }

        }

        private void cboCarMakeModel_SelectedIndexChanged(object sender, EventArgs e)
        {
            myDB.DisplayTransactions(lstPurchases, cboCarMakeModel.Text);
            lblAveragePrice.Text = myDB.GetBalance(cboCarMakeModel.Text).ToString("c");
        }
    }
}
